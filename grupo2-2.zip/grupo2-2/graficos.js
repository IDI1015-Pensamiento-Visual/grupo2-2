var dataset1 = [
    { year: 2016, cantidadIncendios: 610 },
    { year: 2017, cantidadIncendios: 800 },
    { year: 2018, cantidadIncendios: 943 },
    { year: 2019, cantidadIncendios: 1152 },
    { year: 2020, cantidadIncendios: 723 },
    { year: 2021, cantidadIncendios: 894 },
    // ...
  ];
  
  var dataset2 = [
    { year: 2016, cantidadIncendios: 21 },
    { year: 2017, cantidadIncendios: 2 },
    { year: 2018, cantidadIncendios: 8 },
    { year: 2019, cantidadIncendios: 9 },
    { year: 2020, cantidadIncendios: 2 },
    { year: 2021, cantidadIncendios: 4 },
    // ...
  ];
  
  var dataset3 = [
    { year: 2016, cantidadIncendios: 589 },
    { year: 2017, cantidadIncendios: 798 },
    { year: 2018, cantidadIncendios: 935 },
    { year: 2019, cantidadIncendios: 1143 },
    { year: 2020, cantidadIncendios: 721 },
    { year: 2021, cantidadIncendios: 890 },
    // ...
  ];